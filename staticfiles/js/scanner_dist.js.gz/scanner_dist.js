let studentId = document.querySelector("#student_id"),
    studentRes = document.querySelector("#stu_res"),
    activateBtn = document.querySelector("#activate_btn"),
    missingFormBtn = document.querySelector("#missing_form_btn"),
    missingSubmitBtn = document.querySelector("#missing_submit_btn"),
    studentIdNew = document.querySelector("#student_id_new"),
    studentName = document.querySelector("#student_name"),
    stuResNew = document.querySelector("#stu_res_new");
